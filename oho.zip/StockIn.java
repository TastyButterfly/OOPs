import javax.swing.JOptionPane;
import java.util.*;

public class StockIn extends Stock{
    private String stockInID;
    private static Set<String> stockInIDSet=new HashSet<String>();
    private static int count=0;
    private StockRequest SR;
    private int temp;
    public StockIn(){
        while(stockInIDSet.contains(String.format("%s%04d","SI",++count))){
            if(count>=9999) count=0;//RESET COUNT IF IT EXCEEDS 9999, TO PREVENT OVERFLOW
        }//ENSURE NO DUPLICATE IDs
        stockInID=String.format("%s%04d","SI",count);
        stockInIDSet.add(stockInID);
    }
    public StockIn(StockRequest SR){
        while(stockInIDSet.contains(String.format("%s%04d","SI",++count))){
            if(count>=9999) count=0;//RESET COUNT IF IT EXCEEDS 9999, TO PREVENT OVERFLOW
        }//ENSURE NO DUPLICATE IDs
        stockInID=String.format("%s%04d","SI",count);
        stockInIDSet.add(stockInID);
        setSR(SR);
    }
    public StockIn(Product product, int qty, String size){
        while(stockInIDSet.contains(String.format("%s%04d","SI",++count))){
            if(count>=9999) count=0;//RESET COUNT IF IT EXCEEDS 9999, TO PREVENT OVERFLOW
        }//ENSURE NO DUPLICATE IDs
        stockInID=String.format("%s%04d","SI",count);
        stockInIDSet.add(stockInID);
        setPQS(product, qty, size);
    }
    public StockIn(String stockInID, StockRequest SR, Product product, int qty, String size, int d, int m, int y, int h, int min, int s){//FOR USE IN LOADING FROM FILE, DO NOT USE FOR NEW RECORDS
        stockInIDSet.add(stockInID);
        this.stockInID=stockInID;
        this.product=product;
        this.qty=qty;
        this.size=size;
        setSR(SR);
        date.changeDateTime(d, m, y, h, min, s);
        count++;
    }
    //Constructors
    public void changeSIID(String stockInID){
        if(stockInID.matches("SI\\d+")&& stockInID.length()==6 && !(stockInIDSet.contains(stockInID))){//REGEX FOR SIID AND TO ENSURE IT IS NOT A DUPLICATE OF LATEST ID
            stockInIDSet.remove(this.stockInID);
            this.stockInID=stockInID;
            stockInIDSet.add(stockInID);
        }
        else{
            JOptionPane.showMessageDialog(null, "Invalid Stock In ID!", "Warning", JOptionPane.WARNING_MESSAGE);
        }
    }
    //USE WITH CAUTION!!!! COULD BREAK SYSTEM
    public void setSR(StockRequest SR){
        try{
            if(product==SR.getProduct()){
                if(SR!=null){
                    SR.setOutstanding(SR.getOutstanding()+qty);
                }
                this.SR=SR;
                SR.setOutstanding(SR.getOutstanding()-qty);
            }
            else{
                JOptionPane.showMessageDialog(null, "Product does not match Stock Request.\nChanges not made.", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error setting Stock Request.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public boolean setQty(int qty){
        temp=this.qty;
        if(SR!=null && super.setQty(true,qty)){
            SR.setOutstanding((SR.getOutstanding()+temp));
            SR.setOutstanding((SR.getOutstanding()-qty));
            if(SR.getOutstanding()<=0){
                SR.setStatus("Fulfilled");
                SR.setOutstanding(0);
            }
            else{
                SR.setStatus("Partially Fulfilled");
            }
            return true;
        }
        else if(SR==null){
            super.setProdandQty(true,product,qty);
            return true;
        }
        else{
            return false;
        }
    }
    public boolean setProdandQty(Product product, int qty){
        temp=this.qty;
        if(SR!=null && super.setProdandQty(true,product,qty) && product==SR.getProduct()){
            SR.setOutstanding((SR.getOutstanding()+temp));
            SR.setOutstanding((SR.getOutstanding()-qty));
            if(SR.getOutstanding()<=0){
                SR.setStatus("Fulfilled");
                SR.setOutstanding(0);
            }
            else{
                SR.setStatus("Partially Fulfilled");
            }
            return true;
        }
        else if(SR==null){
            super.setProdandQty(true,product,qty);
            return true;
        }
        else{
            return false;
        }
    }
    public boolean setPQS(Product product, int qty, String size){
        temp=this.qty;
        if(SR!=null && product==SR.getProduct() && size.equals(SR.getSize())){
            if(super.setPQS(true,product,qty,size)){
                SR.setOutstanding((SR.getOutstanding()+temp));
                SR.setOutstanding((SR.getOutstanding()-qty));
                if(SR.getOutstanding()<=0){
                    SR.setStatus("Fulfilled");
                    SR.setOutstanding(0);
                }
                else{
                    SR.setStatus("Partially Fulfilled");
                }
                return true;
            }
            else{
                return false;
            }
        }
        else if(SR==null){
            super.setPQS(true,product,qty,size);
            return true;
        }
        else if(product!=SR.getProduct()||size!=SR.getSize()){
            JOptionPane.showMessageDialog(null, "Product or size does not match Stock Request.\nChanges not made.", "Warning", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        else{
            JOptionPane.showMessageDialog(null, "Unexpected error occured.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    //Setters
    public StockRequest getSR(){
        return SR;
    }
    public int getCount(){
        return count;
    }
    public String getSIID(){
        return stockInID;
    }
    //Getters

}
